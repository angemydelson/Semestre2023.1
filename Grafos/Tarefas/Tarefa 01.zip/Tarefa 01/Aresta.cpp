/*
 * Tarefa 01 - Grafo - Listas de Adjacencia
 *
 * GEN254 - Grafos - 2023/1
 *
 * Nome:      Angemydelson Saint Bert
 * Matricula: 2121101002
 */

#include "Aresta.h"

Aresta::Aresta(int v1, int v2) : v1(v1), v2(v2) {
}
