/*
 * Tarefa 03 - Viacao Grafeira
 *
 * GEN254 - Grafos - 2023/1
 *
 * Nome:      XXXX
 * Matricula: XXXX
 */

#ifndef DIGRAFO_H

#define DIGRAFO_H

class Digrafo {

    /* Complete aqui */

};

#endif /* DIGRAFO_H */
