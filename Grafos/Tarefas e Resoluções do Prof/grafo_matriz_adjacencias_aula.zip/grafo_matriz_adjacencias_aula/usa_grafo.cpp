#include "Grafo.h"

int main() {
    Grafo g(10);
    g.imprime();

    return 0;
}