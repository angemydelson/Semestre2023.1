class Aresta {
public:
    const int v1;
    const int v2;
    Aresta(int v1, int v2);
};