#include "Aresta.h"

Aresta::Aresta(int v1, int v2) : v1(v1), v2(v2) {
}