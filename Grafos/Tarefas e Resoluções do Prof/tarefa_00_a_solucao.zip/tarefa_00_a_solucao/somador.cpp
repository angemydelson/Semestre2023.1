/*
 * Tarefa de laboratorio 00 - Somador
 *
 * GEN254 - Grafos - 2023/1
 *
 * Nome:      XXXX
 * Matricula: XXXX
 */

#include <iostream>

using namespace std;

int main() {
    int a;
    int b;

    cin >> a >> b;

    cout << (a + b) << "\n";

    return 0;
}
